import { createButtons } from "./content/buttons.js";

createButtons();
